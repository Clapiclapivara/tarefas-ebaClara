package br.com.hmiku;

public class PrimeiraClasse {

	public static void main(String[] args) {
		System.out.print("Hello World!");
	}

}
